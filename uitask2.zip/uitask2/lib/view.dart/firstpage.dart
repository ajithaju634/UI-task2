import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:uitask2/view.dart/details.dart';

class Firstpage extends StatelessWidget {
  Firstpage({super.key});
  TextEditingController tfcontroler = TextEditingController();
  List<Map<String, dynamic>> userdata = [
    {
      'img': "",
      'studentname': "Ajith",
      'rollno': "1",
      'age': "18",
      'qualification': "plus two"
    },
    {
      'studentname': "Rahul",
      'rollno': "2",
      'age': "18",
      'qualification': "plus two"
    },
    {
      'studentname': "Akash",
      'rollno': "3",
      'age': "18",
      'qualification': "plus two"
    },
    {
      'studentname': "Arjun",
      'rollno': "4",
      'age': "18",
      'qualification': "plus two"
    },
  ];

  List foundlist = [];
  void iniState() {
    foundlist = userdata;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Color.fromARGB(255, 156, 201, 222),
        // appBar: AppBar(
        //   backgroundColor: Colors.black38,
        // ),
        body: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            children: [
              TextField(
                controller: tfcontroler,
                onChanged: (value) => filteritem(value),
                decoration: InputDecoration(
                    hintText: "search",
                    suffixIcon: Icon(Icons.search),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20))),
              ),
              Expanded(
                child: ListView.builder(
                    itemCount: userdata.length,
                    itemBuilder: (context, indexx) {
                      return ListTile(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => Details(
                                        age: userdata[indexx]['age'],
                                        qualification: userdata[indexx]
                                            ['qualification'],
                                        rollno: userdata[indexx]['rollno'],
                                        studentname: userdata[indexx]
                                            ['studentname'])));
                          },
                          title: Text(userdata[indexx]['studentname']),
                          leading: Icon(Icons.person_3));
                    }),
              ),
            ],
          ),
        ));
  }

  void filteritem(String itemName) {
    List result = [];

    if (itemName.trim().isEmpty) {
      result = userdata;
    } else {
      result = userdata
          .where((element) =>
              element.toString().toLowerCase().contains(itemName.toLowerCase()))
          .toList();
    }
    StepState() {
      foundlist = result;
    }
  }
}
