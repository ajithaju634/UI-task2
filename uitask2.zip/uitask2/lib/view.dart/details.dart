import 'package:flutter/material.dart';

class Details extends StatelessWidget {
  String? studentname;
  String? rollno;
  String? age;
  String? qualification;
  Details({
    required this.age,
    required this.qualification,
    required this.rollno,
    required this.studentname,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 165, 209, 230),
      body: Container(
        child: Padding(
          padding: const EdgeInsets.only(left: 170),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "Studentname: $studentname",
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w200),
              ),
              Text('Age: $age'.toString()),
              Text("rollno: $rollno".toString()),
              Text("Qualification: $qualification")
            ],
          ),
        ),
      ),
    );
  }
}
